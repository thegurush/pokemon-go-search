# V78 real-data browser validation
This candidate contains reviewed real ranking data and the user-tested long-query regression. It is NOT a deployment package.
Run all existing preservation, sliders, Python, ranking and Chromium checks, plus real ranking UI tests at counts1/10/30 for all19 groups and four viewport sizes. Synthetic fixtures remain isolated.
No test is skipped; publication permissions are absent. Live website/species updater stay unchanged.
Rankings refresh automation and final held-form disposition remain unfinished. Passing this run is not authorization to merge or publish.
