# V78 accumulated move-search validation

Validate Fly/Thunder same-slot exclusions, typed charged moves, native names, and ordinary/+ move handling, along with all existing browser/preservation/slider/ranking tests. Candidate includes source-pinned metadata, user evidence and semantic regression checks.

All 1,140 top-30 occurrences in the current candidate roster compile locally. This is not completion of form/release/sprite/source review; real rankings are not embedded. Ranking UI browser tests still use synthetic fixtures. Positive ++ searches remain unverified and blocked by the resolver.

Read-only isolated test branch. No deployment, no permission to merge, no external outreach.
