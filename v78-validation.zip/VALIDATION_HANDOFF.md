V78 isolated browser validation checkpoint
Remote testing branch: v78-browser-validation (created from main 301907d182f05a1da1580c592fafb3d4a8d84246).
Browser uploads stalled; no candidate commit or deployment was confirmed.
Upload v78-validation.zip to branch root and validate-v78.yml to .github/workflows/ on that branch.
This workflow validates the extracted candidate only and cannot deploy.
Browser verification is pending. Ranking browser tests use synthetic fixtures; real production rankings remain unfinished. Passing this workflow is not authorization to merge or publish V78.
Existing live website and species updater remain unchanged.
