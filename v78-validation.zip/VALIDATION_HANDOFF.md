# V78 move-search validation

This isolated candidate tests Psychic and typed Hidden Power mappings, automatic Mega moves, existing ranking UI, sliders, selection, and preservation. Ranking browser fixtures are synthetic. Real production rankings remain incomplete.

This workflow has read-only permissions and cannot deploy. A green run is browser evidence for this candidate, not authorization to merge or publish. Main and the live website are unchanged.

Native evidence: the user confirmed the Tyranitar slot tests and all six Butterfree/Starmie queries. Psychic Fangs per-slot exclusions are compiler-tested inference, not directly in-game verified.
