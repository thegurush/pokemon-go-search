Reference versions for testing.
