Pokémon availability data.
