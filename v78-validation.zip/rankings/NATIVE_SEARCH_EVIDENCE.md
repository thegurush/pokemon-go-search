# Native search evidence follow-up

Official help reviewed November 25, 2026 (America/Denver):
https://scopelyexplore.helpshift.com/hc/en/5-pokemon-go/faq/1126-searching-filtering-your-pokemon-inventory/

Documented: @move-name finds a move; @1/@2/@3 with a type distinguishes fast/charged slots; purified and shadow select state; Pokédex numbers select species. The page does not explicitly demonstrate combining a numbered slot with an exact move name. Existing exact-name-slot verification remains pending; no searchVerified flags changed.

The fusion keyword includes both fusion-capable and already-fused Pokémon, so it cannot establish an exact fused form. megaevolve depends on current eligibility/energy and cannot serve as unrestricted potential-Mega identification. Existing approximate species fallbacks remain necessary.

Return mechanic reference:
https://niantic.helpshift.com/hc/en/6-pokemon-go/faq/2396-shadow-pokemon-purified-pokemon/
Return is exclusive to purified Pokémon. This verifies the general mechanic, not release eligibility for every form.

Revised candidate restriction audit: 535 form/move records have matching independent Shadow-release evidence; 8 remain held. Those eight account for 16 scored pairs. Removing them changes none of the 38 top-30 ranking groups under the saved calculation settings. This sensitivity test does not establish release approval or justify including held pairs.

User verification November 26: all five Tyranitar tests behaved as expected. See native-search-user-tests.json. Exact numbered-name syntax is now supported by direct user testing. Other unambiguous catalog names reuse this verified syntax with explicit source-ID/type/name checks; their evidence is labeled reviewed inference, not individually user-tested. Psychic, Hidden Power and ambiguous prefixes remain blocked pending dedicated mapping.

## November 26: Psychic and typed Hidden Power follow-up
User confirmed six native queries for Butterfree (Psychic, only charged slot) and Starmie (Dark Hidden Power). Evidence is in rankings/native-search-user-tests.json. Compiler now adds the actual Hidden Power type and uses psychi with per-slot Psychic Fangs exclusions. Same-slot exclusions are inferred from native grammar and tested locally, not directly observed in game. No second charged unlock is required.

All 21 Python tests, ranking policy/build/session/restriction checks, 24 slider scenarios, preservation and the new move-search semantic tests pass locally. New browser assertions are added but remain pending GitHub execution; Chromium restoration failed with HTTP 403. Prior successful run 45769543750 does not cover these changes.

Rebuilt source scores remain candidate-only: 1,573 forms, 20,051 pairs. Moveset compilation now succeeds for 1,016 of 1,140 top-30 occurrences (38 groups), with 124 still held. These counts are repeated ranking occurrences, not unique species. Remaining source reuse, release/form/sprite and native alias reviews are not complete; no production snapshot is embedded.

Main rechecked at 07d8b341965f686d4d7e0c9becbe19d196724ebc. Its only change from 301907d is data/availability-check.json. No website or daily updater modifications were published by this work. Next: upload the refreshed validation ZIP and YAML to v78-browser-validation, then inspect actual Chromium results. Do not merge this validation package.
