# Native search evidence follow-up

Official help reviewed November 25, 2026 (America/Denver):
https://scopelyexplore.helpshift.com/hc/en/5-pokemon-go/faq/1126-searching-filtering-your-pokemon-inventory/

Documented: @move-name finds a move; @1/@2/@3 with a type distinguishes fast/charged slots; purified and shadow select state; Pokédex numbers select species. The page does not explicitly demonstrate combining a numbered slot with an exact move name. Existing exact-name-slot verification remains pending; no searchVerified flags changed.

The fusion keyword includes both fusion-capable and already-fused Pokémon, so it cannot establish an exact fused form. megaevolve depends on current eligibility/energy and cannot serve as unrestricted potential-Mega identification. Existing approximate species fallbacks remain necessary.

Return mechanic reference:
https://niantic.helpshift.com/hc/en/6-pokemon-go/faq/2396-shadow-pokemon-purified-pokemon/
Return is exclusive to purified Pokémon. This verifies the general mechanic, not release eligibility for every form.

Revised candidate restriction audit: 535 form/move records have matching independent Shadow-release evidence; 8 remain held. Those eight account for 16 scored pairs. Removing them changes none of the 38 top-30 ranking groups under the saved calculation settings. This sensitivity test does not establish release approval or justify including held pairs.
