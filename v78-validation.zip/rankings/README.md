# V78 Top Attackers — implementation checkpoint

This directory contains the implemented policy/build layer. It is connected to index.html with a reviewed real-data candidate snapshot embedded. The candidate is not deployed and final real-data browser verification is pending. Do not upload this checkpoint as a finished V78 release.

Implemented:
- best / NbestTYPE parser;1–30;18 types; default10.
- Custom mixed-pair85% rule, charged-type requirement and own-form comparison.
- Elite-off recalculation, tied best pairs, one rank per battle-form key.
- Independent type groups, global score order, separate occurrence/selection keys.
- Moveset/Elite and Overall/type state transitions.
- Form predicates, approximate-search warnings and charged-slot OR.
- Refusal to generate unverified exact move searches.
- Bounded native-expression compiler and atomic saved-snapshot builder.

Tests:
`node tests/rankings.cjs`
`node tests/ranking_build.cjs`

Builder input is deliberately source-neutral. It requires a reviewed form roster and complete per-pair scores under the approved calculation settings. No code/data was copied from DialgaDex into these modules. Raw research outputs are NOT valid production input. prepare_reviewed.cjs checks matching audit hashes and per-form evidence before build.cjs can produce the saved snapshot. Never set review flags just to make a build pass.

Unfinished:
- Reviewed form-level release mapping; the pinned source adapter now produces candidate scores.
- Source/data reuse clarification, complete asset mapping and in-game move-expression verification.
- Approved podium is integrated. Podium renderer screenshot reviewed after successful GitHub Chromium run 45757838709.
- App integration is implemented locally, but candidate browser verification passed on GitHub; real-data completion remains pending.
- New-feature browser/mobile checks and GitHub testing/publication.

The existing pending V78 Mega Evolvable correction is retained in index.html and its tests. The daily species updater and publishing workflows are unchanged. All work will be delivered as one combined release after completion.

The session bridge uses separate `form:` selection keys and type/form occurrence keys. Synthetic data in tests/ranking_fixture.cjs must never become production data. The integration patch register in app-edits.json lets preservation tests reverse exact additions before comparing the approved baseline.

Real-source continuation

`dialgadex-adapter.cjs`, `candidate_roster.py` and `audit_scores.cjs` now build and audit real-source candidate rankings. See SOURCE_NOTES.md and source-audit.json. Candidate data remains blocked from production. Restricted-state moves carry a separate requiredState; they are not mislabeled as Elite moves. Potential searches omit the state requirement, while Moveset ON includes it. Tests: node tests/ranking_restrictions.cjs (also invoked by preservation).
