# Real-source adapter checkpoint

This is an offline candidate-data calculation, not an enabled production feed.
The application still has no real snapshot embedded.

`dialgadex-adapter.cjs` executes a local, pinned DialgaDex checkout. The calculator
remains in that checkout and is not embedded in the application. DialgaDex's
GPL-3.0 notices remain upstream; data-source reuse review remains recorded as
unfinished. No author was contacted and no permission is claimed.

Calculator revision: eef2ddbb822bae0c0f4f5060115aef39dbea091a
Data revision: e88e23950e58968f2283625a6fdd65506195796d
Each file must match its committed bytes. Upstream changes stop calculation until
reviewed. The only in-memory calculator patch removes its 50-moveset truncation;
all eligible pairs are needed for our own mixed-type and Elite-off ranking rules.

Explicit calculation settings: level40, eDPS, fixed opponent defense180, selected
type effectiveness1.6, neutral Overall, solo, six-member team, ten-second relobby,
0.5-second PvE timing, speculative previews off, temporary Mega boost level1.
The original Hidden Power placeholder is excluded; actual type variants retain
separate move identities even when they share a numeric move ID.

Candidate forms cross-check species IDs, released flags and types with PvPoke.
PvPoke's `none` second-type sentinel is normalized away. A matching candidate is
NOT automatically a reviewed identity, sprite or native-search mapping.

Reproduce from the saved investigation inputs and pinned checkouts:

```sh
python rankings/candidate_roster.py form-audit.csv rankings/release-candidates.json pvpoke-current.json pokemon-resources/pogo_pkm.min.json candidate-roster.json
node rankings/dialgadex-adapter.cjs dialgadex pokemon-resources candidate-roster.json candidate-scores.json
node rankings/audit_scores.cjs candidate-scores.json candidate-roster.json rankings/source-audit.json
```

The audit covers all18 attacking types plus Overall with Elite on/off. It must not
be displayed as final rankings. Outstanding issues include missing form/sprite
mappings, Smeargle's missing source move pool, and special-move eligibility.
Upstream places purification-only moves alongside Elite moves. The adapter now
uses the source's separate purified/Shadow move pools to classify these correctly:
requiredState is independent of Elite, and Elite OFF retains purification-only
moves. Moveset ON adds that state to the predicate, while potential-performance
search does not. Actual release eligibility for each restricted pair is still
unreviewed, so candidate scores remain blocked from publication.
Official mechanic reference: https://niantic.helpshift.com/hc/en/6-pokemon-go/faq/2396-shadow-pokemon-purified-pokemon/
The help page states Return is exclusive to purified Pokémon. This does not verify
individual form release eligibility or exact move-name searches in game.
Native move-name/slot searches remain unverified and fail closed in Moveset ON.

All candidate results retain false review flags, and the production builder is
tested to reject them. Never change those flags merely to make publication pass.

Additional audits (November 25):
- audit_restrictions.cjs matches restricted-state pairs to independent Shadow release records: 533 candidate matches, 8 held. Aliases remain unreviewed; these results do not set approval flags.
- audit_sprite_identity.py checks all 1,561 mapped sprites against PokeAPI species IDs: all match. Exact alternate-form identity is a separate review.
- audit_sprites.py downloads each unique sprite, checks PNG decoding/dimensions/nonempty alpha, and records hashes. It requires Pillow for image validation; partial runs are explicitly marked INCOMPLETE.
- Browser dependency restoration and isolated GitHub validation status are in VALIDATION_STATUS.md.
