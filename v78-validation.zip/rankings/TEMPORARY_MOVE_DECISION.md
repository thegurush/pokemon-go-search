APPROVED by user: raid rankings, automatic Mega attacks included with Elite OFF, fast-only Moveset requirement for these pairs. Implemented in core, adapter and embedded HTML; browser rerun pending.

# Temporary Mega move decision — pending user review

Official reference opened November 25, 2026:
https://pokemongo.com/news/more-mega-updates-2026

Eligible Megas receive an additional charged attack while Mega Evolved at any Mega Level; attack power scales with Mega Level. These attacks are not usable against Gym defenders. The existing calculation uses Mega Level 1.

Pinned upstream GetPokemonMoves puts temp_cm into elite_cm. That category is unsuitable for Tap to Search's Elite toggle: these attacks are automatically granted, not taught with Elite TMs. Scenario audit reclassifies only explicitly listed temp_cm, never inferred plus-sign names, and does not mutate candidate input.

72 scored pairs are temporary Mega pairs. Correcting their Elite classification changes 12 of 38 top-30 groups. Including versus excluding them changes 21 of 38 groups. Counts cover 19 categories with Elite on/off separately.

Decision required: recommend raid rankings including automatically granted Mega attacks. For Moveset ON, such pairs should require the appropriate fast attack and form capability, not a learned copy of the temporary charged attack or current Mega transformation. This is an explicit exception to the approved ordinary fast+charged search requirement. Alternative: exclude temporary Mega attacks from both ranking modes, sacrificing raid coverage while avoiding this exception. Do not silently switch policy.

No production data or application changes made for this scenario. Exact native names/slots and held forms remain separate work. Tests: node tests/temporary_moves.cjs.
