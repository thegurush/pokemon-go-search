#!/usr/bin/env python3
"""Verify candidate sprite form identifiers, separately from release/search approval."""
import argparse, csv, hashlib, json, re
from pathlib import Path

# Explicit differences between the source's form names and PokeAPI identifiers.
ALIASES = {
    'nidoran_female': ('Normal', 'nidoran-f'),
    'nidoran_male': ('Normal', 'nidoran-m'),
    'tauros_combat': ('Paldea_combat', 'tauros-paldea-combat-breed'),
    'tauros_aqua': ('Paldea_aqua', 'tauros-paldea-aqua-breed'),
    'tauros_blaze': ('Paldea_blaze', 'tauros-paldea-blaze-breed'),
    'cherrim_overcast': ('Overcast', 'cherrim'),
    'deoxys': ('Normal', 'deoxys-normal'),
    'meowstic': ('Normal', 'meowstic-male'),
    'zygarde': ('Fifty_percent', 'zygarde-50'),
    'necrozma_dawn_wings': ('Dawn_wings', 'necrozma-dawn'),
    'necrozma_dusk_mane': ('Dusk_mane', 'necrozma-dusk'),
    'zacian_hero': ('Hero', 'zacian'),
    'zacian_crowned_sword': ('Crowned_sword', 'zacian-crowned'),
    'zamazenta_hero': ('Hero', 'zamazenta'),
    'zamazenta_crowned_shield': ('Crowned_shield', 'zamazenta-crowned'),
    'oinkologne': ('Normal', 'oinkologne-male'),
}

def expected_identifier(form):
    key = form['key']
    if form['shadow']:
        if not key.endswith('_shadow'):
            raise ValueError('Shadow key missing state suffix')
        key = key[:-7]
    elif key.endswith('_shadow'):
        raise ValueError('Shadow suffix conflicts with state')
    if key in ALIASES:
        label, identifier = ALIASES[key]
        if form['upstreamForm'] != label:
            raise ValueError('Alias form label changed')
        return identifier, 'explicit form alias'
    tokens = key.split('_')
    regions = {'alolan':'alola','galarian':'galar','hisuian':'hisui','paldean':'paldea'}
    return '-'.join(regions.get(t,t) for t in tokens), 'matching form identifier'

def audit(roster_path, pokemon_path):
    roster = json.loads(Path(roster_path).read_text())
    with Path(pokemon_path).open() as stream:
        pokemon = {int(r['id']):r for r in csv.DictReader(stream)}
    rows = []
    for form in roster['forms']:
        match = re.search(r'/([0-9]+)\.png$', form['sprite'])
        record = pokemon.get(int(match[1])) if match else None
        try:
            expected, method = expected_identifier(form)
            ok = bool(record and int(record['species_id']) == form['species'] and record['identifier'] == expected)
            reason = '' if ok else 'Sprite species or exact form identifier mismatch'
        except ValueError as error:
            expected, method, ok, reason = None, 'held', False, str(error)
        rows.append({'form':form['key'], 'upstreamForm':form['upstreamForm'], 'expectedIdentifier':expected,
                     'actualIdentifier':record['identifier'] if record else None, 'method':method,
                     'status':'matched' if ok else 'held', 'reason':reason})
    return {'scope':'Sprite identity only. Does not approve release eligibility, native searches, cosmetic deduplication or data reuse.',
            'rosterSha256':hashlib.sha256(Path(roster_path).read_bytes()).hexdigest(),
            'pokemonSha256':hashlib.sha256(Path(pokemon_path).read_bytes()).hexdigest(),
            'matched':sum(r['status']=='matched' for r in rows), 'held':sum(r['status']=='held' for r in rows), 'rows':rows}

if __name__ == '__main__':
    parser=argparse.ArgumentParser();parser.add_argument('roster');parser.add_argument('pokemon');parser.add_argument('output');args=parser.parse_args()
    result=audit(args.roster,args.pokemon);Path(args.output).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['matched','held']}))
