#!/usr/bin/env python3
"""Cross-check candidate identities. This does not approve or publish a roster."""
import argparse,csv,hashlib,json
from pathlib import Path

def create(audit_path,release_path,pvpoke_path,source_path):
    raw=Path(pvpoke_path).read_bytes();digest=hashlib.sha256(raw).hexdigest()
    pv={p['speciesId']:p for p in json.loads(raw)['pokemon']}
    mappings={r['form']:r for r in json.loads(Path(release_path).read_text())['rows']}
    upstream={(p['id'],p['form']):p for p in json.loads(Path(source_path).read_text())}
    forms=[];held=[];seen=set()
    for row in csv.DictReader(open(audit_path)):
        m=mappings[row['pokemon_form']];dex=int(row['species_id']);key=m['candidateSourceId'];p=pv.get(key);u=upstream.get((dex,row['form']))
        reason=None
        if m['sourceStatus']!='positive source flag' or not p or p.get('released') is not True:reason='No positive independent form-release match'
        elif p['dex']!=dex:reason='Species identifier mismatch'
        elif not u or u.get('released') is not True:reason='Upstream form unavailable'
        elif not row['sprite_url']:reason='Missing sprite mapping'
        elif sorted(t for t in p['types'] if t!='none')!=sorted(t.lower() for t in u['types']):reason='Cross-source typing mismatch'
        elif key in seen:reason='Duplicate candidate identity'
        if reason:
            held.append({'form':row['pokemon_form'],'sourceId':key,'reason':reason});continue
        seen.add(key);shadow=row['pokemon_form'].startswith('Shadow ')
        forms.append({'key':key,'species':dex,'name':p['speciesName'],'shadow':shadow,'released':True,'releaseEvidence':[{'source':'PvPoke','id':key,'released':True,'sha256':digest}],'sprite':row['sprite_url'],'search':{'terms':[str(dex),'shadow' if shadow else '!shadow'],'accuracy':'partial','limitation':'Species and Shadow status only; other forms may also match.'},'upstreamForm':row['form'],'sourceTypes':p['types'],'reviewed':False})
    return {'schema':1,'sources':[{'url':'https://raw.githubusercontent.com/pvpoke/pvpoke/master/src/data/gamemaster.json','sha256':digest}],'forms':forms,'held':held,'status':'Candidate mappings only; held forms and all asset/search mappings require review'}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('audit');p.add_argument('releases');p.add_argument('pvpoke');p.add_argument('source');p.add_argument('output');a=p.parse_args()
    result=create(a.audit,a.releases,a.pvpoke,a.source);Path(a.output).write_text(json.dumps(result,indent=2));print(json.dumps({'candidates':len(result['forms']),'held':len(result['held'])}))
