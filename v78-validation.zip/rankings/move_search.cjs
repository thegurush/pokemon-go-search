'use strict';
// Evidence for syntax is separate from per-move identity and ambiguity review.
const R=require('./core.cjs');
const EVIDENCE='user-tyranitar-slot-tests-2026-11-26';
const OBSERVED=new Set(['smack down','stone edge','brutal swing']);
function resolve(move,slot,catalog){
 const name=String(move.name||'').toLowerCase();
 const rows=catalog.filter(x=>String(x.id)+':'+String(x.type).toLowerCase()===move.key);
 const blocked=reason=>({searchName:name,searchVerified:false,searchReview:{reason}});
 if(!['fast','charged'].includes(slot)||!name||/[,&|:;!@<>\r\n]/.test(name))return blocked('Invalid move search metadata');
 if(!rows.some(x=>x.name.toLowerCase()===name))return blocked('Move ID/type/name does not match source catalog');
 if(slot==='fast'&&name.startsWith('hidden power ')){
  const t=name.slice('hidden power '.length);
  if(!R.TYPES.includes(t)||t!==String(move.type).toLowerCase()||['normal','fairy'].includes(t))return blocked('Invalid Hidden Power type mapping');
  return {searchName:'hidden power',searchType:t,searchVerified:true,searchReview:{syntaxEvidence:'user-starmie-hidden-power-tests-2026-11-26',verification:t==='dark'?'User-tested name and actual type':'Typed mapping inferred from user-tested Dark Hidden Power syntax'}};
 }
 if(slot==='charged'&&name==='psychic')return {searchName:'psychi',searchExclusions:['psychic fangs'],searchVerified:true,searchReview:{syntaxEvidence:'user-butterfree-psychic-tests-2026-11-26',verification:'Psychi and either-slot syntax user-tested; same-slot Psychic Fangs exclusion is a compiler inference, not individually in-game tested'}};
 if(R.TYPES.includes(name))return blocked('Move name is also a type keyword');
 if(name.startsWith('hidden power ')||/plus|\+|blastoise|pink|green/.test(name))return blocked('Source-specific name requires explicit native mapping');
 if(catalog.some(x=>x.name.toLowerCase()!==name&&x.name.toLowerCase().startsWith(name)))return blocked('Same-slot move-name prefix collision');
 return {searchName:name,searchVerified:true,searchReview:{syntaxEvidence:EVIDENCE,identity:'Source catalog ID, type and name match; no same-slot prefix/type collision',verification:OBSERVED.has(name)?'User-tested name and slot syntax':'Reviewed source name using documented move search and user-tested slot syntax'}};
}
module.exports={resolve,EVIDENCE};
