const A=require('node:assert/strict'),{resolve}=require('../rankings/move_search.cjs');
const catalog=[{id:1,type:'Rock',name:'Smack Down'},{id:2,type:'Dark',name:'Brutal Swing'},{id:3,type:'Electric',name:'Thunder'},{id:4,type:'Electric',name:'Thunderbolt'},{id:5,type:'Psychic',name:'Psychic'},{id:6,type:'Normal',name:'Hidden Power Ice'},{id:7,type:'Water',name:'Liquidation+'},{id:8,type:'Grass',name:'Vine Whip'}];
const m=(i,name,type)=>({key:i+':'+type,name});
A(resolve(m(1,'Smack Down','rock'),'fast',catalog).searchVerified);
A(resolve(m(2,'Brutal Swing','dark'),'charged',catalog).searchVerified);
A.equal(resolve(m(8,'Vine Whip','grass'),'fast',catalog).searchReview.verification,'Reviewed source name using documented move search and user-tested slot syntax');
for(const [id,name,type] of [[3,'Thunder','electric'],[6,'Hidden Power Ice','normal'],[7,'Liquidation+','water'],[1,'Wrong Name','rock']])A.equal(resolve(m(id,name,type),'charged',catalog).searchVerified,false);
console.log('PASS move identity and slot evidence: safe names admitted, prefix/type/source aliases blocked, observations distinguished from inference');
const R=require('../rankings/core.cjs');
const hp=resolve({key:'9:dark',name:'Hidden Power Dark',type:'dark'},'fast',[{id:9,name:'Hidden Power Dark',type:'Dark'}]);
A.equal(hp.searchType,'dark');A.equal(hp.searchName,'hidden power');A(hp.searchVerified);
const psychic=resolve(m(5,'Psychic','psychic'),'charged',catalog);
A.equal(psychic.searchName,'psychi');A.deepEqual(psychic.searchExclusions,['psychic fangs']);
const form={key:'test',name:'Test',search:{accuracy:'exact',terms:['121']}};
const pair={fast:{...hp,type:'dark'},charged:psychic};
const make=p=>R.predicate([{form:'test',movesets:[p]}],[form],{moveset:true}).ast;
const compiled=R.stringify(make(pair));
function token(t,moves){let neg=t.startsWith('!');if(neg)t=t.slice(1);if(t==='121')return !neg;const [,slot,name]=t.match(/^@(\d)(.*)$/);const move=moves[Number(slot)-1];const yes=!!move&&(move.name.startsWith(name)||move.type===name);return neg?!yes:yes;}
function query(q,moves){return q.split('&').every(c=>c.split(',').some(t=>token(t,moves)));}
const fast={name:'hidden power',type:'dark'},psych={name:'psychic',type:'psychic'},fangs={name:'psychic fangs',type:'psychic'},other={name:'aqua jet',type:'water'};
for(const [moves,expected] of [[[fast,psych],true],[[fast,other,psych],true],[[fast,fangs],false],[[fast,psych,fangs],true],[[fast,fangs,psych],true],[[{...fast,type:'ice'},psych],false],[[fast,other],false]])A.equal(query(compiled,moves),expected,JSON.stringify(moves));
A(!compiled.includes('!@psychic fangs'));
A.throws(()=>make({...pair,fast:{...pair.fast,searchType:'dark&shiny'}}),/typed move/);
A.throws(()=>make({...pair,charged:{...psychic,searchExclusions:['psychic fangs,shiny']}}),/exclusions/);
console.log('PASS Psychic either-slot matching, same-slot Fangs exclusions, single charged slot and Hidden Power actual type; unsafe metadata rejected');
