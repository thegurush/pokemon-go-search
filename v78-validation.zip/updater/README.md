Daily Pokémon availability updater.
